CREATE DATABASE `Chat`;

USE `Chat`;

CREATE TABLE `Mensajes` (
  `id` int(11) AUTO_INCREMENT,
  `mensaje` varchar(280) NOT NULL,
  `user_name` varchar(40) NOT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `Mensajes`
    (`id`, `mensaje`, `user_name`, `fecha`)
VALUES
    (1, `Bienvenides`, `Admin`, NOW());
